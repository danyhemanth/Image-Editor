
# Image Editor

The Image editor is Intesnsity transformation GUI toolbox which allows one to perform mutiple Intesnsity transformation.<br />
The features included in the tool are Histogram Equalization, Gamma correction, log transform, blur image, shapen image and color invert.<br />
The code has 3 main global variable: <br />
1)currimagematrix : stores the current image displayed in array form, <br />
2) imglist : This is a list of image matrix that have been displayed to form a stack,<br />
3)currimage: this is the image format of current image being displayed.<br />

To run this project run:
```
    $ python3 imageeditor.py
```

